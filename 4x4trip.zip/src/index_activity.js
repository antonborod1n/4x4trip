import "./scss/main.scss";
import './modules/header';
import './modules/tabs';
import './modules/script';